Cupcakes version of [2048](http://gabrielecirulli.github.io/2048/) game
========================================================================

Play here: http://0x0800.github.io/2048-CUPCAKES/

[![2048 CUPCAKES](http://oi62.tinypic.com/9u7rkk.jpg)](http://0x0800.github.io/2048-CUPCAKES/)
